package router

type RouterGroup struct {
	RegisterRouter
}

var RouterGroupApp = new(RouterGroup)
