package service

type ServiceGroup struct {
	RegisterService
}

var ServiceGroupApp = new(ServiceGroup)
