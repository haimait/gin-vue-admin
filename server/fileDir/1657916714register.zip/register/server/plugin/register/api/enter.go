package api

type ApiGroup struct {
	RegisterApi
}

var ApiGroupApp = new(ApiGroup)
