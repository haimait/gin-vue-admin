package config

type Register struct {
	Name        string // 用户名
	AuthorityId uint   // 权限ID
}
