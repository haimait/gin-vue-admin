package global

import "github.com/flipped-aurora/gin-vue-admin/server/plugin/register/config"

var GlobalConfig = new(config.Register)
